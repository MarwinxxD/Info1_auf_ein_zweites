int main(void){
    char w[3];
    int *p = &w[2];
}