int ** p;

int main(void){}