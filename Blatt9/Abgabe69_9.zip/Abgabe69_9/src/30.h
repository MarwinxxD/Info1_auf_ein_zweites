#ifndef DREIZIG_H
#define DREIZIG_H

#include<stdio.h>

#define ISPRIME(x) printf("\nDIGAAAAA %i ist DIE Primzahl", x)
#define ABSTANT(a,b) (a > b) ? a - b : b - a

int prim(int a);
int quad(int q);

#endif