int main(void){
    int n;
    int *p = &n;
}